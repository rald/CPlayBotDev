#ifndef COMMON_H
#define COMMON_H
 
int SCREEN_WIDTH = 800;
int SCREEN_HEIGHT = 600;

#endif
